﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vücut_kitle_endeksi_hesaplama
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vücut ağırlığınızı giriniz: ");
            double kg = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Boyunuzu giriniz: ");
            double by = Convert.ToDouble(Console.ReadLine());
            double vke  = kg / (by * by);
            if (vke < 18)
            {
                Console.WriteLine("Zayıf");
            }
            else if (vke >= 18.5 && vke < 24.9)
            {
                Console.WriteLine(" Normal Kilolu");
            }
            else if (vke >= 25 && vke < 29.9)
            {
                Console.WriteLine("Kilolu");
            }
            else 
            {
                Console.WriteLine("Obez");
            }

            Console.ReadKey();
        }
    }
}
